package com.jusco;


/**
 * Created by srikanth on 21/01/2016.
 */
public class uploadRec {


    public String getTot_rebate() {
        return tot_rebate;
    }

    public void setTot_rebate(String tot_rebate) {
        this.tot_rebate = tot_rebate;
    }

    public String getCat_tariff() {
        return cat_tariff;
    }

    public void setCat_tariff(String cat_tariff) {
        this.cat_tariff = cat_tariff;
    }

    public String getCur_MD() {
        return Cur_MD;
    }

    public void setCur_MD(String cur_MD) {
        Cur_MD = cur_MD;
    }

    String Cur_MD;

    public String getSBM_NO() {
        return SBM_NO;
    }

    public void setSBM_NO(String SBM_NO) {
        this.SBM_NO = SBM_NO;
    }



    public String getBP_Number() {
        return BP_Number;
    }

    public void setBP_Number(String BP_Number) {
        this.BP_Number = BP_Number;
    }

    public String getCURR_READING() {
        return CURR_READING;
    }

    public void setCURR_READING(String CURR_READING) {
        this.CURR_READING = CURR_READING;
    }

    public String getMRNOTE() {
        return MRNOTE;
    }

    public void setMRNOTE(String MRNOTE) {
        this.MRNOTE = MRNOTE;
    }

    public String getBILLED_UNITS() {
        return BILLED_UNITS;
    }

    public void setBILLED_UNITS(String BILLED_UNITS) {
        this.BILLED_UNITS = BILLED_UNITS;
    }

    public String getNETUNITS() {
        return NETUNITS;
    }

    public void setNETUNITS(String NETUNITS) {
        this.NETUNITS = NETUNITS;
    }

    public String getENERGY_CHARGE() {
        return ENERGY_CHARGE;
    }

    public void setENERGY_CHARGE(String ENERGY_CHARGE) {
        this.ENERGY_CHARGE = ENERGY_CHARGE;
    }

    public String getE_DUTY() {
        return E_DUTY;
    }

    public void setE_DUTY(String e_DUTY) {
        E_DUTY = e_DUTY;
    }

    public String getMETER_RENT() {
        return METER_RENT;
    }

    public void setMETER_RENT(String METER_RENT) {
        this.METER_RENT = METER_RENT;
    }

    public String getFIXEDCHARGE() {
        return FIXEDCHARGE;
    }

    public void setFIXEDCHARGE(String FIXEDCHARGE) {
        this.FIXEDCHARGE = FIXEDCHARGE;
    }

    public String getLPC() {
        return LPC;
    }

    public void setLPC(String LPC) {
        this.LPC = LPC;
    }

    public String getINTERESTONSD() {
        return INTERESTONSD;
    }

    public void setINTERESTONSD(String INTERESTONSD) {
        this.INTERESTONSD = INTERESTONSD;
    }

    public String getTDS() {
        return TDS;
    }

    public void setTDS(String TDS) {
        this.TDS = TDS;
    }

    public String getRebateEarly() {
        return RebateEarly;
    }

    public void setRebateEarly(String rebateEarly) {
        RebateEarly = rebateEarly;
    }

    public String getRebateDigital() {
        return RebateDigital;
    }

    public void setRebateDigital(String rebateDigital) {
        RebateDigital = rebateDigital;
    }

    public String getOTHERRECEIVABLE() {
        return OTHERRECEIVABLE;
    }

    public void setOTHERRECEIVABLE(String OTHERRECEIVABLE) {
        this.OTHERRECEIVABLE = OTHERRECEIVABLE;
    }

    public String getPREVIOUSOS() {
        return PREVIOUSOS;
    }

    public void setPREVIOUSOS(String PREVIOUSOS) {
        this.PREVIOUSOS = PREVIOUSOS;
    }

    public String getFPPPACharg() {
        return FPPPACharg;
    }

    public void setFPPPACharg(String FPPPACharg) {
        this.FPPPACharg = FPPPACharg;
    }

    public String getBill_Amt() {
        return Bill_Amt;
    }

    public void setBill_Amt(String bill_Amt) {
        Bill_Amt = bill_Amt;
    }

    public String getTOTAL() {
        return TOTAL;
    }

    public void setTOTAL(String TOTAL) {
        this.TOTAL = TOTAL;
    }



    public String getLAT() {
        return LAT;
    }

    public void setLAT(String LAT) {
        this.LAT = LAT;
    }

    public String getLONG() {
        return LONG;
    }

    public void setLONG(String LONG) {
        this.LONG = LONG;
    }

    public String getSBM_Sw_Ver() {
        return SBM_Sw_Ver;
    }

    public void setSBM_Sw_Ver(String SBM_Sw_Ver) {
        this.SBM_Sw_Ver = SBM_Sw_Ver;
    }

    public String getBILL_NO() {
        return BILL_NO;
    }

    public void setBILL_NO(String BILL_NO) {
        this.BILL_NO = BILL_NO;
    }

    public String getBill_Date() {
        return Bill_Date;
    }

    public void setBill_Date(String bill_Date) {
        Bill_Date = bill_Date;
    }

    public String getBill_Time() {
        return Bill_Time;
    }

    public void setBill_Time(String bill_Time) {
        Bill_Time = bill_Time;
    }

    public String getCons_Mob_No() {
        return Cons_Mob_No;
    }

    public void setCons_Mob_No(String cons_Mob_No) {
        Cons_Mob_No = cons_Mob_No;
    }

    public String getCur_Mtr_Sts() {
        return Cur_Mtr_Sts;
    }

    public void setCur_Mtr_Sts(String cur_Mtr_Sts) {
        Cur_Mtr_Sts = cur_Mtr_Sts;
    }

    public String getPrev_Read() {
        return Prev_Read;
    }

    public void setPrev_Read(String prev_Read) {
        Prev_Read = prev_Read;
    }

    public String getPres_Read_KW_RMD() {
        return Pres_Read_KW_RMD;
    }

    public void setPres_Read_KW_RMD(String pres_Read_KW_RMD) {
        Pres_Read_KW_RMD = pres_Read_KW_RMD;
    }

    public String getCur_PF() {
        return Cur_PF;
    }

    public void setCur_PF(String cur_PF) {
        Cur_PF = cur_PF;
    }

    public String getBill_Due_date() {
        return Bill_Due_date;
    }

    public void setBill_Due_date(String bill_Due_date) {
        Bill_Due_date = bill_Due_date;
    }

    public String getRound_Off_amount() {
        return Round_Off_amount;
    }

    public void setRound_Off_amount(String round_Off_amount) {
        Round_Off_amount = round_Off_amount;
    }

    public String getBill_Net_within_due_date() {
        return Bill_Net_within_due_date;
    }

    public void setBill_Net_within_due_date(String bill_Net_within_due_date) {
        Bill_Net_within_due_date = bill_Net_within_due_date;
    }

    public String getBill_Amount_After_Due_Date() {
        return Bill_Amount_After_Due_Date;
    }

    public void setBill_Amount_After_Due_Date(String bill_Amount_After_Due_Date) {
        Bill_Amount_After_Due_Date = bill_Amount_After_Due_Date;
    }

    public String getBill_Generation_Status() {
        return Bill_Generation_Status;
    }

    public void setBill_Generation_Status(String bill_Generation_Status) {
        Bill_Generation_Status = bill_Generation_Status;
    }

    public String getMeter_Reader_Name() {
        return Meter_Reader_Name;
    }

    public void setMeter_Reader_Name(String meter_Reader_Name) {
        Meter_Reader_Name = meter_Reader_Name;
    }

    public String getObr_Code() {
        return Obr_Code;
    }

    public void setObr_Code(String obr_Code) {
        Obr_Code = obr_Code;
    }

    public String getOnline_Flag_number() {
        return Online_Flag_number;
    }

    public void setOnline_Flag_number(String online_Flag_number) {
        Online_Flag_number = online_Flag_number;
    }

    public String getRdg_img_Path() {
        return Rdg_img_Path;
    }

    public void setRdg_img_Path(String rdg_img_Path) {
        Rdg_img_Path = rdg_img_Path;
    }


    String BP_Number;//1
    String CURR_READING;//2
    String MRNOTE;//3
    String BILLED_UNITS;//4
    String NETUNITS;//5
    String ENERGY_CHARGE;//6
    String E_DUTY;//7
    String METER_RENT;//8
    String FIXEDCHARGE;//9
    String LPC;//10
    String INTERESTONSD;//11
    String TDS;//12
    String RebateEarly;//13
    String RebateDigital;//14
    String OTHERRECEIVABLE;//15
    String PREVIOUSOS;//16
    String FPPPACharg;//17
    String Bill_Amt;//18
    String TOTAL;//19
    String cat_tariff;//20
    String tot_rebate;//21
    String SBM_NO;//22
    String LAT;//23
    String LONG;//24
    String SBM_Sw_Ver;//25
    String BILL_NO;//26
    String Bill_Date;//27
    String Bill_Time;//28
    String Cons_Mob_No;//29
    String Cur_Mtr_Sts;//30
    String Prev_Read;//31
    String Pres_Read_KW_RMD;//32
    String Cur_PF;//33
    String Bill_Due_date;//34
    String Round_Off_amount;//35
    String Bill_Net_within_due_date;//36
    String Bill_Amount_After_Due_Date;//37
    String Bill_Generation_Status;//38
    String Meter_Reader_Name;//39
    String Obr_Code;//40
    String Online_Flag_number;//41
    String Rdg_img_Path;//42

    public String getMETER_SERIAL_NO() {
        return METER_SERIAL_NO;
    }

    public void setMETER_SERIAL_NO(String METER_SERIAL_NO) {
        this.METER_SERIAL_NO = METER_SERIAL_NO;
    }

    String METER_SERIAL_NO;
}
