package com.jusco;

public class SbmRec {
    public String getBP_Number() {
        return BP_Number;
    }

    public void setBP_Number(String BP_Number) {
        this.BP_Number = BP_Number;
    }

    public String getBP_NAME() {
        return BP_NAME;
    }

    public void setBP_NAME(String BP_NAME) {
        this.BP_NAME = BP_NAME;
    }

    public String getBP_ADDRESS1() {
        return BP_ADDRESS1;
    }

    public void setBP_ADDRESS1(String BP_ADDRESS1) {
        this.BP_ADDRESS1 = BP_ADDRESS1;
    }

    public String getBP_ADDRESS2() {
        return BP_ADDRESS2;
    }

    public void setBP_ADDRESS2(String BP_ADDRESS2) {
        this.BP_ADDRESS2 = BP_ADDRESS2;
    }

    public String getBP_ADDRESS3() {
        return BP_ADDRESS3;
    }

    public void setBP_ADDRESS3(String BP_ADDRESS3) {
        this.BP_ADDRESS3 = BP_ADDRESS3;
    }

    public String getSanc_Load() {
        return Sanc_Load;
    }

    public void setSanc_Load(String sanc_Load) {
        Sanc_Load = sanc_Load;
    }

    public String getMeter_Number() {
        return Meter_Number;
    }

    public void setMeter_Number(String meter_Number) {
        Meter_Number = meter_Number;
    }

    public String getMobile_Number() {
        return Mobile_Number;
    }

    public void setMobile_Number(String mobile_Number) {
        Mobile_Number = mobile_Number;
    }

    public String getMeter_Phase() {
        return Meter_Phase;
    }

    public void setMeter_Phase(String meter_Phase) {
        Meter_Phase = meter_Phase;
    }

    public String getDTR_Number() {
        return DTR_Number;
    }

    public void setDTR_Number(String DTR_Number) {
        this.DTR_Number = DTR_Number;
    }

    public String getFeeder_Name() {
        return Feeder_Name;
    }

    public void setFeeder_Name(String feeder_Name) {
        Feeder_Name = feeder_Name;
    }

    public String getDTR_Location() {
        return DTR_Location;
    }

    public void setDTR_Location(String DTR_Location) {
        this.DTR_Location = DTR_Location;
    }

    public String getPrev_Billing_Date() {
        return Prev_Billing_Date;
    }

    public void setPrev_Billing_Date(String prev_Billing_Date) {
        Prev_Billing_Date = prev_Billing_Date;
    }

    public String getCons1() {
        return Cons1;
    }

    public void setCons1(String cons1) {
        Cons1 = cons1;
    }

    public String getCons2() {
        return Cons2;
    }

    public void setCons2(String cons2) {
        Cons2 = cons2;
    }

    public String getCons3() {
        return Cons3;
    }

    public void setCons3(String cons3) {
        Cons3 = cons3;
    }

    public String getCons4() {
        return Cons4;
    }

    public void setCons4(String cons4) {
        Cons4 = cons4;
    }

    public String getCons5() {
        return Cons5;
    }

    public void setCons5(String cons5) {
        Cons5 = cons5;
    }

    public String getCons6() {
        return Cons6;
    }

    public void setCons6(String cons6) {
        Cons6 = cons6;
    }

    public String getPOSTINGDATE() {
        return POSTINGDATE;
    }

    public void setPOSTINGDATE(String POSTINGDATE) {
        this.POSTINGDATE = POSTINGDATE;
    }

    public String getCON_DATE() {
        return CON_DATE;
    }

    public void setCON_DATE(String CON_DATE) {
        this.CON_DATE = CON_DATE;
    }

    public String getDL_COUNTER() {
        return DL_COUNTER;
    }

    public void setDL_COUNTER(String DL_COUNTER) {
        this.DL_COUNTER = DL_COUNTER;
    }

    public String getCATEGORY() {
        return CATEGORY;
    }

    public void setCATEGORY(String CATEGORY) {
        this.CATEGORY = CATEGORY;
    }

    public String getE_Duty_Identifier() {
        return E_Duty_Identifier;
    }

    public void setE_Duty_Identifier(String e_Duty_Identifier) {
        E_Duty_Identifier = e_Duty_Identifier;
    }

    public String getPREV_READ() {
        return PREV_READ;
    }

    public void setPREV_READ(String PREV_READ) {
        this.PREV_READ = PREV_READ;
    }

    public String getMRNOTE() {
        return MRNOTE;
    }

    public void setMRNOTE(String MRNOTE) {
        this.MRNOTE = MRNOTE;
    }

    public String getAMOUNT01() {
        return AMOUNT01;
    }

    public void setAMOUNT01(String AMOUNT01) {
        this.AMOUNT01 = AMOUNT01;
    }

    public String getAMOUNT02() {
        return AMOUNT02;
    }

    public void setAMOUNT02(String AMOUNT02) {
        this.AMOUNT02 = AMOUNT02;
    }

    public String getMF() {
        return MF;
    }

    public void setMF(String MF) {
        this.MF = MF;
    }

    public String getMETER_RENT() {
        return METER_RENT;
    }

    public void setMETER_RENT(String METER_RENT) {
        this.METER_RENT = METER_RENT;
    }

    public String getLPC() {
        return LPC;
    }

    public void setLPC(String LPC) {
        this.LPC = LPC;
    }

    public String getINTERESTONSD() {
        return INTERESTONSD;
    }

    public void setINTERESTONSD(String INTERESTONSD) {
        this.INTERESTONSD = INTERESTONSD;
    }

    public String getTDS() {
        return TDS;
    }

    public void setTDS(String TDS) {
        this.TDS = TDS;
    }

    public String getRebateEarly() {
        return RebateEarly;
    }

    public void setRebateEarly(String rebateEarly) {
        RebateEarly = rebateEarly;
    }

    public String getRebateDigital() {
        return RebateDigital;
    }

    public void setRebateDigital(String rebateDigital) {
        RebateDigital = rebateDigital;
    }

    public String getOTHERRECEIVABLE() {
        return OTHERRECEIVABLE;
    }

    public void setOTHERRECEIVABLE(String OTHERRECEIVABLE) {
        this.OTHERRECEIVABLE = OTHERRECEIVABLE;
    }

    public String getPREVIOUSOS() {
        return PREVIOUSOS;
    }

    public void setPREVIOUSOS(String PREVIOUSOS) {
        this.PREVIOUSOS = PREVIOUSOS;
    }

    public String getFPPPACharg() {
        return FPPPACharg;
    }

    public void setFPPPACharg(String FPPPACharg) {
        this.FPPPACharg = FPPPACharg;
    }

    public String getOffice_Addr() {
        return office_Addr;
    }

    public void setOffice_Addr(String office_Addr) {
        this.office_Addr = office_Addr;
    }

    public String getOffice_Phone() {
        return office_Phone;
    }

    public void setOffice_Phone(String office_Phone) {
        this.office_Phone = office_Phone;
    }

    public String getPrev_rdg_dt() {
        return Prev_rdg_dt;
    }

    public void setPrev_rdg_dt(String prev_rdg_dt) {
        Prev_rdg_dt = prev_rdg_dt;
    }

    public String getBilling_Status() {
        return Billing_Status;
    }

    public void setBilling_Status(String billing_Status) {
        Billing_Status = billing_Status;
    }

    public String getOld_Meter_Number() {
        return Old_Meter_Number;
    }

    public void setOld_Meter_Number(String old_Meter_Number) {
        Old_Meter_Number = old_Meter_Number;
    }

    public String getReplacement_Dt() {
        return Replacement_Dt;
    }

    public void setReplacement_Dt(String replacement_Dt) {
        Replacement_Dt = replacement_Dt;
    }

    public String getOld_mtr_final_rdg() {
        return Old_mtr_final_rdg;
    }

    public void setOld_mtr_final_rdg(String old_mtr_final_rdg) {
        Old_mtr_final_rdg = old_mtr_final_rdg;
    }

    public String getNew_mtr_initial_rdg() {
        return New_mtr_initial_rdg;
    }

    public void setNew_mtr_initial_rdg(String new_mtr_initial_rdg) {
        New_mtr_initial_rdg = new_mtr_initial_rdg;
    }

    String BP_Number;
    String BP_NAME;
    String BP_ADDRESS1;
    String BP_ADDRESS2;
    String BP_ADDRESS3;
    String Sanc_Load;
    String Meter_Number;
    String Mobile_Number;
    String Meter_Phase;
    String DTR_Number;
    String Feeder_Name;
    String DTR_Location;
    String Prev_Billing_Date;
    String Cons1;
    String Cons2;
    String Cons3;
    String Cons4;
    String Cons5;
    String Cons6;
    String POSTINGDATE;
    String CON_DATE;
    String DL_COUNTER;
    String CATEGORY;
    String E_Duty_Identifier;
    String PREV_READ;
    String MRNOTE;
    String AMOUNT01 ;
    String AMOUNT02 ;
    String MF;
    String METER_RENT ;
    String LPC ;
    String INTERESTONSD ;
    String TDS ;
    String RebateEarly ;
    String RebateDigital ;
    String OTHERRECEIVABLE ;
    String PREVIOUSOS ;
    String FPPPACharg ;
    String office_Addr;
    String office_Phone;
    String Prev_rdg_dt;
    String Billing_Status;
    String Old_Meter_Number;
    String Replacement_Dt;
    String Old_mtr_final_rdg;
    String New_mtr_initial_rdg;
    String kwh_adj;

    public String getKwh_adj() {
        return kwh_adj;
    }

    public void setKwh_adj(String kwh_adj) {
        this.kwh_adj = kwh_adj;
    }

    public String getEd_adj() {
        return ed_adj;
    }

    public void setEd_adj(String ed_adj) {
        this.ed_adj = ed_adj;
    }

    String ed_adj;

    public String getUOM() {
        return UOM;
    }

    public void setUOM(String UOM) {
        this.UOM = UOM;
    }

    String UOM;

    public String getSchedule_MR_Date() {
        return Schedule_MR_Date;
    }

    public void setSchedule_MR_Date(String schedule_MR_Date) {
        Schedule_MR_Date = schedule_MR_Date;
    }

    String Schedule_MR_Date;

    public String getFixedCharge() {
        return FixedCharge;
    }

    public void setFixedCharge(String fixedCharge) {
        FixedCharge = fixedCharge;
    }

    String FixedCharge;

}
