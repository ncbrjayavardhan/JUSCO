package com.jusco;

import android.app.Application;

/**
 * Created by srikanth on 13/02/2016.
 */
public class BilledRecords extends Application{
    public String servno;
    public String Book;
    public String SeqNo;
    public String Billdate  ;
    public String Billtime ;
    public String BillNo ;
    public String BMnths ;
    public String MnthMin ;
    public String  Sload;
    public String CurLoad ;
    public String  CurPF ;
    public String curread ;
    public String CurStatus;
    public String BUnits ;
    public String  PrevAdjUnits ;
    public String  FixedChrg ;
    public String  EnrgyChrg ;
    public String str1="00" ;
    public String ED ;
    public String CurIntrest;
    public String IntPEDArrs;
    public String str2 ="00" ;
    public String  DLAdjAmntED;
    public String str3="00" ;
    public String Group;
    public String str4="00";
    public String  BillLG;
    public String  NetAmntExArr;
    public String  ArrearsOld;
    public String  ArrearsCur;
    public String NetAmntInArr;
    public String  str5="00";
    public String  str6="00";
    public String  str7="00";
    public String  str8="00";
    public String str9="00";
    public String  str10="00";
    public String  AssdUnits;
    public String  str11="00" ;
    public String str12="00000000";
    public String  ObrCode;
    public String  SBA_ID;
    public String MacID;
    public String  str13="0000000000";
    public String  Duedt;
    public String  Discdt;
    public String str14="00";
    public String Prevreading;
    public String  ArrNR;
    public String  CapChrg;
    public String  str15="00";
    public String  str16="00";
    public String  MtrCost;
    public String RODO_Amt;
    public String OTS_Amt;
    public String  Regulatory_ch;
    public String  str17="0000000000";
    public String  Telno;
    public String fRebateB_amt;
    public String  MinChrg;
    public String imageFileName;
    public String imageFileName2;
    public Double Arrear;
    public Double latitude;
    public Double longitude;
    public String Areacode;
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
