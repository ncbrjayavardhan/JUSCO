package com.jusco;
import java.util.List;
public class DataPojo {
    public List<uploadRec> getData() {
        return data;
    }

    public void setData(List<uploadRec> data) {
        this.data = data;
    }

    List<uploadRec> data;
}
